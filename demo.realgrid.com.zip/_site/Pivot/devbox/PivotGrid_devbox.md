#### 피벗 AND 그리드

<a class="btn primary small round lowercase" id="btnDrawPivot">변경내용을 피벗에 적용</a>

```js
pivot.buildPivot();
```


<script>
$('#btnDrawPivot').click(function() {
	pivot.buildPivot();
});
</script>